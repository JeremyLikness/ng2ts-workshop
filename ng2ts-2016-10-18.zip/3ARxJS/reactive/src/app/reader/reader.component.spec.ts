/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ReaderComponent } from './reader.component';

describe('Component: Reader', () => {
  it('should create an instance', () => {
    let component = new ReaderComponent();
    expect(component).toBeTruthy();
  });
});
