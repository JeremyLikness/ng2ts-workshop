# Angular 2 Intro Lab Steps

[View the Deck](./00Intro/ng2.pptx)

