/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { SliderComponent } from './slider.component';

describe('Component: Slider', () => {
  it('should create an instance', () => {
    let component = new SliderComponent();
    expect(component).toBeTruthy();
  });
});
