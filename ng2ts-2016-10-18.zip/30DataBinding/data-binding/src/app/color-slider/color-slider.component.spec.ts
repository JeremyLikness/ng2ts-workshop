/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ColorSliderComponent } from './color-slider.component';

describe('Component: ColorSlider', () => {
  it('should create an instance', () => {
    let component = new ColorSliderComponent();
    expect(component).toBeTruthy();
  });
});
