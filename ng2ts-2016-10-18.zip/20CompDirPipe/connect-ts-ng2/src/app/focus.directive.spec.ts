/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { FocusDirective } from './focus.directive';

describe('Directive: Focus', () => {
  it('should create an instance', () => {
    let directive = new FocusDirective();
    expect(directive).toBeTruthy();
  });
});
