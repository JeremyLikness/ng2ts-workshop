/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ExperimentComponent } from './experiment.component';

describe('Component: Experiment', () => {
  it('should create an instance', () => {
    let component = new ExperimentComponent();
    expect(component).toBeTruthy();
  });
});
